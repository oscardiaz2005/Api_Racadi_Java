package com.Racadi.Academy.Racadi_Academy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RacadiAcademyApplication {

	public static void main(String[] args) {
		SpringApplication.run(RacadiAcademyApplication.class, args);
	}

}
