package com.Racadi.Academy.Racadi_Academy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RacadiAcademyApplicationTests {

	@Test
	void contextLoads() {
	}

}
